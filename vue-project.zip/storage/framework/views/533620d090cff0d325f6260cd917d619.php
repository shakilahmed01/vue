<div class="pagetitle">
    <h1><?php echo e($pageTitle ?? ''); ?></h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active"><?php echo e($pageTitle ?? ''); ?></li>
        </ol>
    </nav>
</div><?php /**PATH G:\wamp64\www\vue-project\resources\views/admin/include/breadcrumb.blade.php ENDPATH**/ ?>