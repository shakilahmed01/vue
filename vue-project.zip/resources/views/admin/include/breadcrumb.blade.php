<div class="pagetitle">
    <h1>{{ $pageTitle ?? '' }}</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active">{{ $pageTitle ?? '' }}</li>
        </ol>
    </nav>
</div>