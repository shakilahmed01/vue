<template>
    <div>
        <!-- Application Header -->
        <header class="bg-primary text-white p-3 mb-4">
            <h1 class="text-center">Attendance</h1>
        </header>
    </div>
</template>

<script>

</script>
